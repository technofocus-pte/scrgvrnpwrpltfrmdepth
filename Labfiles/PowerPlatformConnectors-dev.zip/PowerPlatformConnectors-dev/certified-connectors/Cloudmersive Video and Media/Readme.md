
## Cloudmersive Video and Media
[Video and Media API](https://cloudmersive.com/video-and-media-services-api) covers a wide array of common video and audio processing needs, including encoding, decoding, editing, resizing, moderating and extracting metadata.  Stateless high-security processing ensures fast performance and strong security.


## Pre-requisites
N/A


## API documentation
[Video and Media API](https://api.cloudmersive.com/docs/video.asp) is available on the Cloudmersive website


## Supported Operations

### Convert Audio File to MP3 format
Automatically detect audio file format and convert it to MP3 format. Supports many input audio formats, including AAC, FLAC, M4A, MP2, MP3, OGG, WMA, and WAV.

### Convert Audio File to M4A format
Automatically detect audio file format and convert it to M4A format. Supports many input audio formats, including AAC, FLAC, M4A, MP2, MP3, OGG, WMA, and WAV.

### Convert Audio File to AAC format
Automatically detect audio file format and convert it to AAC format. Supports many input audio formats, including AAC, FLAC, M4A, MP2, MP3, OGG, WMA, and WAV.

### Convert Audio File to WAV format
Automatically detect audio file format and convert it to WAV format. Supports many input audio formats, including AAC, FLAC, M4A, MP2, MP3, OGG, WMA, and WAV.

### Get detailed information about a video or audio file
Retrieve detailed information about a video or audio file, including format, dimensions, file size, bit rate, duration and start time. Compatible with many formats, including: AVI, ASF, FLV, GIF, MP4, MPEG/MPG, Matroska/WEBM, MOV, AIFF, ASF, CAF, MP3, MP2, MP1, Ogg, OMG/OMA, and WAV

### Convert Video to WEBM format
Automatically detect video file format and convert it to WEBM format. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.

### Convert Video to MOV format
Automatically detect video file format and convert it to MOV format. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.

### Convert Video to MP4 format
Automatically detect video file format and convert it to MP4 format. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.

### Convert Video to Animated GIF format
Automatically detect video file format and convert it to animated GIF format. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.

### Resizes a Video Preserving the Original Aspect Ratio
Resizes a video, while maintaining the original aspect ratio and encoding. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, MKV, M4V and MOV.

### Resizes a Video without Preserving Aspect Ratio
Resizes a video without maintaining original aspect ratio, allowing fully customizable dimensions. May cause image skewing. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, MKV, M4V and MOV.

### Cut a Video to a Shorter Length
Cuts a video to the specified start and end times. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, MKV, M4V and MOV. Uses 1 API call per 10 MB of file size.

### Split a Video into Two Shorter Videos
Cuts a video into two videos based on the specified start time. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, MKV, M4V and MOV.

### Convert Video to PNG Still Frames
Automatically detect video file format and convert it to an array of still frame PNG images. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.

### Scan a Video for NSFW content
Automatically detect video file format and scan it for Not Safe For Work (NSFW)/Porn/Racy content. Supports many input video formats, including AVI, ASF, FLV, MP4, MPEG/MPG, Matroska/WEBM, 3G2, OGV, MKV, M4V and MOV.


## How to get credentials
- [Register](https://account.cloudmersive.com/signup) for a Cloudmersive Account
- [Sign In](https://account.cloudmersive.com/login) with your Cloudmersive Account and click on API Keys

Here you can create and see your API key(s) listed on the API Keys page.  Simply copy and paste this API Key into the Cloudmersive Video and Media Connector.

Now you are ready to start using the Cloudmersive Video and Media Connector.


## Deployment instructions
Please use [these instructions](https://docs.microsoft.com/en-us/connectors/custom-connectors/paconn-cli) to deploy this connector as custom connector in Microsoft Power Automate and Power Apps

