# 1Me Corporate
1Me is the easiest and fastest way to share your contact information.
With 1Me, you can have an unlimited number of contact cards. You can choose which contact information to include on each card, and then choose who to share each card with.
This is best for separating your business and personal contact information


## Publisher: 1Me
 

## Prerequisites
You will need the following to proceed:
Request an API key.
Link:- https://corporate.1me.live/


## Supported Operations

### Retrieve Card Templates
Retrieve all corporate card templates.

### Send Invitation
Create invitation and send email for your corporate members.

### Disassociate Member
Disassociate members from your corporate.

### Retrieve All Invitations
Retrieve all corporate invitations.

## Obtaining Credentials
This Connector use API key authentication. ​

## Known Issues and Limitations
No known issues currently.
No Limitations currently.


## Deployment Instructions
To use 1me corporate connector, please Join us by using This Link:-(https://www.1me.live/corporate).
