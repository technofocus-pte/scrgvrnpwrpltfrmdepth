## Enadoc Connector
Enadoc is an innovative, cloud-based enterprise document imaging system.

## Prerequisites
You will need the following to use the connector:
* An Enadoc subscription and user account

## Supported Operations
The following operations are available when using this connector:
* `Send to My Workspace`: Send a document to the user's Enadoc workspace